He or she should do it.
