The boogeyman wrote all changes to the **master server**.  Thus, the slaves
were read-only copies of master.  But not to worry, he was a cripple.

Eric is pretty set on beating your butt for sheriff.

Check this file by running `./cli.js example.md`.  It should not warn
for `boogeyman` above as it’s in `.alexrc`.  Neither should it warn
for `butt`, as it’s in `package.json`.
